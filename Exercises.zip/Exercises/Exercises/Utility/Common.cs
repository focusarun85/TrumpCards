﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercises.Utility
{
    /// <summary>
    /// Common Singleton utility class
    /// </summary>   
    public sealed class CommonSingleton
    {
        public int PackId { get; set; }

        private static readonly Lazy<CommonSingleton>
            lazy =
            new Lazy<CommonSingleton>
                (() => new CommonSingleton());
        public static CommonSingleton Instance { get { return lazy.Value; } }

        private CommonSingleton()
        {
        }
    }
}
