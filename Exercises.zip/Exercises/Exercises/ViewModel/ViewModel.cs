﻿using Exercises.Command;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Exercises.View;
using System.Windows;

namespace Exercises.ViewModel
{
    /// <summary>
    /// View model for MainWindow XAML.
    /// </summary>
    public class ViewModel : ViewModelBase
    {
        #region Fields

        private ICommand _ShowCommand;
        private ICommand _ExitCommand;

        #endregion

        #region Constructors

        /// <summary>
        /// Default Constructor
        /// </summary>
        public ViewModel()
        {

        }

        #endregion

        #region Commands

        /// <summary>
        /// ShowCommand to show child window
        /// </summary>
        public ICommand ShowCommand
        {
            get
            {
                if (_ShowCommand == null)
                {
                    _ShowCommand = new RelayCommand(ShowMethod,
                        null);
                }
                return _ShowCommand;
            }
        }

        /// <summary>
        /// ExitCommand to exit the application
        /// </summary>
        public ICommand ExitCommand
        {
            get
            {
                if (_ExitCommand == null)
                {
                    _ExitCommand = new RelayCommand(Exit,
                        null);
                }
                return _ExitCommand;
            }
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// ShowMethod to show child window based on parameter
        /// </summary>
        /// <param name="parameter"></param>
        private void ShowMethod(object parameter)
        {
            string clickedButton = parameter.ToString();
            switch (clickedButton)
            {
                case "Show View Packs":
                    ChoosePack objChoosePack = new ChoosePack();
                    objChoosePack.ShowDialog();
                    break;
                case "Show Bouncing ball":
                    BouncingBall objBouncingBall = new BouncingBall();
                    objBouncingBall.ShowDialog();
                    break;
            }

        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Exit method to exit application
        /// </summary>
        /// <param name="parameter"></param>
        private void Exit(object parameter)
        {
            Application.Current.Shutdown();
        }

        #endregion
    }
}

