﻿using Exercises.Command;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using Exercises.Model;
using Exercises.Data;
using System.Windows;
using Exercises.View;
using Exercises.Utility;

namespace Exercises.ViewModel
{
    /// <summary>
    /// View model for ChoosePack XAML
    public class ChoosePackViewModel
    {
        #region Fields

        private ICommand _OKCommand;
        private ICommand _CancelCommand;

        #endregion

        #region Constructors

        /// <summary>
        /// Default Constructor to initialize card packs object
        /// </summary>
        public ChoosePackViewModel()
        {
            lstCardPacks = GetCardPacks();

        }

        #endregion

        #region Properties

        public List<CardPack> lstCardPacks { get; set; }

        #endregion

        #region Commands

        public ICommand OKCommand
        {
            get
            {
                if (_OKCommand == null)
                {
                    _OKCommand = new RelayCommand(ShowSelectedPack,
                        null);
                }
                return _OKCommand;
            }
        }

        public ICommand CancelCommand
        {
            get
            {
                if (_CancelCommand == null)
                {
                    _CancelCommand = new RelayCommand(Close,
                        null);
                }
                return _CancelCommand;
            }
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// get Card packs from tblPacks table
        /// </summary>
        /// <returns></returns>
        public List<CardPack> GetCardPacks()
        {
            using (var dbCardsData = new CardsDataContext())
            {
                return (from CardPacks in dbCardsData.tblPacks
                        select new CardPack()
                        {
                            PackId = CardPacks.PackId,
                            PackName = CardPacks.PackName,
                            DesignImage = CardPacks.DesignImage,
                            Description = CardPacks.Description,
                            Category1 = CardPacks.Category1,
                            Category2 = CardPacks.Category2,
                            Category3 = CardPacks.Category3,
                            Category4 = CardPacks.Category4,
                        }).ToList();
            }
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Show selected pack window based on pack id
        /// </summary>
        /// <param name="parameter"></param>
        private void ShowSelectedPack(object parameter)
        {
            if (parameter != null)
            {
                int packId = ((CardPack)parameter).PackId;
                CommonSingleton.Instance.PackId= packId;
                SelectedPack objSelectedPack = new SelectedPack();
                objSelectedPack.ShowDialog();

            }
            else
            {
                MessageBox.Show("You haven't chosen pack yet!");
            }
           
        }

        /// <summary>
        /// Close current window
        /// </summary>
        /// <param name="parameter"></param>               
        private void Close(object parameter)
        {
            if (parameter != null)
            {
                ((Window)parameter).Close();
            }

        }

        #endregion
    }
}
