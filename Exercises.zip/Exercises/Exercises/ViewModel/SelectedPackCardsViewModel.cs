﻿using Exercises.Command;
using Exercises.Data;
using Exercises.Model;
using Exercises.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace Exercises.ViewModel
{
    /// <summary>
    /// View model for SelectedPackCards XAML.
    /// </summary>
    public class SelectedPackCardsViewModel:ViewModelBase
    {
        #region Fields

        public string packName;
        public string cardTitle;
        public string imageName;
        public string category1;
        public string category2;
        public string category3;
        public string category4;
        public int score1;
        public int score2;
        public int score3;
        public int score4;

        private ICommand _PrevRecordCommand;
        private ICommand _NextRecordCommand;
        private ICommand _CancelCommand;

        int recordNumber = 1;



        #endregion

        #region Constructors

        /// <summary>
        /// Default Constructor to initialize pack cards object and Fetch first record
        /// </summary>
        public SelectedPackCardsViewModel()
        {
            ObjPackCards = GetPackCards(CommonSingleton.Instance.PackId);
            if (ObjPackCards != null && ObjPackCards.Count >= recordNumber)
            {
                FetchRecord(recordNumber);

            }
        }

        #endregion

        #region Properties

        public List<PackCards> ObjPackCards { get; set; }

        public string PackName
        {
            get { return packName; }
            set
            {
                packName = value;
                // Call OnPropertyChanged whenever the property is updated
                NotifyPropertyChanged("PackName");
            }
        }

        public string CardTitle
        {
            get { return cardTitle; }
            set
            {
                cardTitle = value;
                // Call OnPropertyChanged whenever the property is updated
                NotifyPropertyChanged("CardTitle");
            }
        }

        public string ImageName
        {
            get { return imageName; }
            set
            {
                imageName = value;
                // Call OnPropertyChanged whenever the property is updated
                NotifyPropertyChanged("ImageName");
            }
        }

        public string Category1
        {
            get { return category1; }
            set
            {
                category1 = value;
                // Call OnPropertyChanged whenever the property is updated
                NotifyPropertyChanged("Category1");
            }
        }

        public string Category2
        {
            get { return category2; }
            set
            {
                category2 = value;
                // Call OnPropertyChanged whenever the property is updated
                NotifyPropertyChanged("Category2");
            }
        }

        public string Category3
        {
            get { return category3; }
            set
            {
                category3 = value;
                // Call OnPropertyChanged whenever the property is updated
                NotifyPropertyChanged("Category3");
            }
        }

        public string Category4
        {
            get { return category4; }
            set
            {
                category4 = value;
                // Call OnPropertyChanged whenever the property is updated
                NotifyPropertyChanged("Category4");
            }
        }

        public int Score1
        {
            get { return score1; }
            set
            {
                score1 = value;
                // Call OnPropertyChanged whenever the property is updated
                NotifyPropertyChanged("Score1");
            }
        }

        public int Score2
        {
            get { return score2; }
            set
            {
                score2 = value;
                // Call OnPropertyChanged whenever the property is updated
                NotifyPropertyChanged("Score2");
            }
        }

        public int Score3
        {
            get { return score3; }
            set
            {
                score3 = value;
                // Call OnPropertyChanged whenever the property is updated
                NotifyPropertyChanged("Score3");
            }
        }

        public int Score4
        {
            get { return score4; }
            set
            {
                score4 = value;
                // Call OnPropertyChanged whenever the property is updated
                NotifyPropertyChanged("Score4");
            }
        }

        #endregion

        #region Commands

        public ICommand PrevRecordCommand
        {
            get
            {
                if (_PrevRecordCommand == null)
                {
                    _PrevRecordCommand = new RelayCommand(MoveToPreRecord,
                        IsPrevRecordAvailable);
                }
                return _PrevRecordCommand;
            }
        }

        public ICommand NextRecordCommand
        {
            get
            {
                if (_NextRecordCommand == null)
                {
                    _NextRecordCommand = new RelayCommand(MoveToNextRecord,
                        IsNextRecordAvailable);
                }
                return _NextRecordCommand;
            }
        }

        public ICommand CancelCommand
        {
            get
            {
                if (_CancelCommand == null)
                {
                    _CancelCommand = new RelayCommand(Close,
                        null);
                }
                return _CancelCommand;
            }
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Get pack cards based on packId from vwCards view
        /// </summary>
        /// <param name="packId"></param>
        /// <returns></returns>
        public List<PackCards> GetPackCards(int packId)
        {
            using (var dbPackCardsData = new CardsDataContext())
            {
                return (from PackCards in dbPackCardsData.vwCards
                        where PackCards.PackId == packId
                        select new PackCards()
                        {
                            CardId = PackCards.CardId,
                            CardTitle = PackCards.CardTitle,
                            ImageName = PackCards.ImageName,
                            PackName = PackCards.PackName,
                            PackId = PackCards.PackId.Value,
                            Description = PackCards.Description,
                            Category1 = PackCards.Category1,
                            Category2 = PackCards.Category2,
                            Category3 = PackCards.Category3,
                            Category4 = PackCards.Category4,
                            Score1 = PackCards.Score1.Value,
                            Score2 = PackCards.Score2.Value,
                            Score3 = PackCards.Score3.Value,
                            Score4 = PackCards.Score4.Value
                        }).ToList();
            }
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Move to previous record
        /// </summary>
        /// <param name="parameter"></param>
        private void MoveToPreRecord(object parameter)
        {
            --recordNumber;
            if (recordNumber>=1)
            {
                FetchRecord(recordNumber);
            }
        }

        /// <summary>
        /// Check if previous record available
        /// </summary>
        /// <param name="parameter"></param>
        /// <returns></returns>
        private bool IsPrevRecordAvailable(object parameter)
        {
            if (recordNumber==1)
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// Move to next record
        /// </summary>
        /// <param name="parameter"></param>
        private void MoveToNextRecord(object parameter)
        {
            ++recordNumber;
            if (ObjPackCards != null && ObjPackCards.Count >= recordNumber)
            {
                FetchRecord(recordNumber);
            }
        }

        /// <summary>
        /// Check if next record available
        /// </summary>
        /// <param name="parameter"></param>
        /// <returns></returns>
        private bool IsNextRecordAvailable(object parameter)
        {
            if (ObjPackCards != null && ObjPackCards.Count >= recordNumber + 1)
            {
                return true;
            }
            return false;
        }      

        /// <summary>
        /// Close current window
        /// </summary>
        /// <param name="parameter"></param>
        private void Close(object parameter)
        {
            if (parameter != null)
            {
                ((Window)parameter).Close();
            }
        }             

        /// <summary>
        /// Method to fetch Pack cards record based on recordNumber
        /// </summary>
        /// <param name="recordNumber"></param>
        private void FetchRecord(int recordNumber)
        {
            PackCards objPackCards = ObjPackCards[recordNumber-1];
            if (objPackCards != null)
            {
                this.PackName = objPackCards.PackName;
                this.CardTitle = objPackCards.CardTitle;
                this.ImageName = objPackCards.ImageName;
                this.Category1 = objPackCards.Category1;
                this.Category2 = objPackCards.Category2;
                this.Category3 = objPackCards.Category3;
                this.Category4 = objPackCards.Category4;
                this.Score1 = objPackCards.Score1;
                this.Score2 = objPackCards.Score2;
                this.Score3 = objPackCards.Score3;
                this.Score4 = objPackCards.Score4;
            }
        }

        #endregion
    }
}
