﻿using Exercises.Command;
using Exercises.Data;
using Exercises.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Exercises.Utility;
using System.Windows;
using Exercises.View;

namespace Exercises.ViewModel
{
    /// <summary>
    /// View model for SelectedPack XAML.
    /// </summary>
    public class SelectedPackViewModel
    {
        #region Fields

        private ICommand _ShowCardCommand;
        private ICommand _CancelCommand;

        #endregion

        #region Constructors

        /// <summary>
        /// Default Constructor to initialize properties value
        /// </summary>
        public SelectedPackViewModel()
        {
            CardPack ObjCardPack = GetCardPack(CommonSingleton.Instance.PackId);
            if (ObjCardPack != null)
            {
                this.PackName = ObjCardPack.PackName;
                this.DesignImage = ObjCardPack.DesignImage;
                this.Category1 = ObjCardPack.Category1;
                this.Category2 = ObjCardPack.Category2;
                this.Category3 = ObjCardPack.Category3;
                this.Category4 = ObjCardPack.Category4;
            }
        }

        #endregion

        #region Properties
        public string PackName { get; set; }
        public string DesignImage { get; set; }
        public string Category1 { get; set; }
        public string Category2 { get; set; }
        public string Category3 { get; set; }
        public string Category4 { get; set; }

        #endregion

        #region Commands

        public ICommand ShowCardCommand
        {
            get
            {
                if (_ShowCardCommand == null)
                {
                    _ShowCardCommand = new RelayCommand(ShowTrumpCards,
                        null);
                }
                return _ShowCardCommand;
            }
        }

        public ICommand CancelCommand
        {
            get
            {
                if (_CancelCommand == null)
                {
                    _CancelCommand = new RelayCommand(Close,
                        null);
                }
                return _CancelCommand;
            }
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Get CardPack based on PackId 
        /// </summary>
        /// <param name="packId"></param>
        /// <returns></returns>
        public CardPack GetCardPack(int packId)
        {
            using (var dbCardsData = new CardsDataContext())
            {
                return (from CardPacks in dbCardsData.tblPacks
                        where CardPacks.PackId == packId
                        select new CardPack()
                        {
                            PackId = CardPacks.PackId,
                            PackName = CardPacks.PackName,
                            DesignImage = CardPacks.DesignImage,
                            Description = CardPacks.Description,
                            Category1 = CardPacks.Category1,
                            Category2 = CardPacks.Category2,
                            Category3 = CardPacks.Category3,
                            Category4 = CardPacks.Category4,
                        }).ToList()[0];
            }
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Show PackCards window
        /// </summary>
        /// <param name="parameter"></param>
        private void ShowTrumpCards(object parameter)
        {
            SelectedPackCards objSelectedPackCards = new SelectedPackCards();
            objSelectedPackCards.ShowDialog();           
        }

        /// <summary>
        /// Close current window
        /// </summary>
        /// <param name="parameter"></param>       
        private void Close(object parameter)
        {
            if (parameter != null)
            {
                ((Window)parameter).Close();
            }
        }

        #endregion
    }
}
