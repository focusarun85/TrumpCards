﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercises.Model
{
    /// <summary>
    /// CardPack class
    /// </summary>
    public class CardPack
    {
        #region Properties
        public int PackId { get; set; }
        public string PackName { get; set; }
        public string DesignImage { get; set; }
        public string Description { get; set; }
        public string Category1 { get; set; }
        public string Category2 { get; set; }
        public string Category3 { get; set; }
        public string Category4 { get; set; }

        #endregion
    }
}
