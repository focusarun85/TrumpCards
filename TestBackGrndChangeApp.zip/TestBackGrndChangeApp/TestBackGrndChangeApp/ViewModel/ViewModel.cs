﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using TestBackGrndChangeApp.Command;

namespace TestBackGrndChangeApp.ViewModel
{
   public class ViewModel
    {
        private ICommand _ChangeColor;

        public ICommand ChangeColor
        {
            get
            {
                if (_ChangeColor == null)
                {
                    _ChangeColor = new RelayCommand(ChangeColorMethod,
                        null);
                }
                return _ChangeColor;
            }
        }

        /// <summary>
        /// Change background color of window
        /// </summary>
        /// <param name="parameter"></param>       
        private void ChangeColorMethod(object parameter)
        {
            if (parameter != null)
            {
             //   Window window2 = new Window();
                Random random = new Random();
                SolidColorBrush brush =
                    new SolidColorBrush(
                        Color.FromRgb(
                        (byte)random.Next(255),
                        (byte)random.Next(255),
                        (byte)random.Next(255)
                        ));
                ((Window)parameter).Background = brush;
            }
        }

    }
}
